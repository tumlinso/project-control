from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path
from typing import Sequence

from .config import apply_config_migration, config_path, config_summary, init_config, load_config, migrate_config_dry_run, save_config
from .migration import MigrationError
from .mutation import MutationRejected
from .preledger import PreledgerError
from .registry import RegistryError, WorkspaceRegistry
from .snapshot import SnapshotBuilder, resolve_skills_root, resolve_todo_provider
from .terminal import BubblewrapSandbox
from .runtime_identity import runtime_diagnostics


def _live_link(value: str) -> tuple[str, Path]:
    relative, separator, target = value.partition("=")
    if not separator or not relative or not target:
        raise argparse.ArgumentTypeError("live link must be PATH=ABSOLUTE_TARGET")
    return relative, Path(target)


def _terminal_service_constraints() -> dict[str, object]:
    """Inspect only bounded systemd policy fields relevant to bubblewrap."""

    try:
        completed = subprocess.run(
            [
                "systemctl", "--user", "show", "project-control.service",
                "--property=LoadState", "--property=ActiveState",
                "--property=RestrictAddressFamilies", "--property=RestrictNamespaces",
            ],
            stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            text=True,
            timeout=2,
            check=False,
        )
    except (OSError, subprocess.TimeoutExpired):
        return {
            "status": "unavailable", "compatible": None,
            "error_code": "project_control_service_policy_unavailable",
        }
    fields = dict(
        line.split("=", 1) for line in completed.stdout.splitlines() if "=" in line
    )
    if completed.returncode != 0 or fields.get("LoadState") != "loaded":
        return {"status": "not_installed", "compatible": None, "error_code": None}
    address_families = fields.get("RestrictAddressFamilies", "").split()
    if address_families and "AF_NETLINK" not in address_families:
        return {
            "status": "incompatible", "compatible": False,
            "error_code": "bwrap_service_address_family_restricted",
            "required_address_family": "AF_NETLINK",
            "active": fields.get("ActiveState") == "active",
        }
    if fields.get("RestrictNamespaces") in {"yes", "true"}:
        return {
            "status": "incompatible", "compatible": False,
            "error_code": "bwrap_service_namespaces_restricted",
            "active": fields.get("ActiveState") == "active",
        }
    return {
        "status": "compatible", "compatible": True, "error_code": None,
        "active": fields.get("ActiveState") == "active",
    }


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="project-control")
    commands = parser.add_subparsers(dest="command", required=True)

    config = commands.add_parser("config")
    config_commands = config.add_subparsers(dest="config_command", required=True)
    config_commands.add_parser("init")
    migrate = config_commands.add_parser("migrate")
    migration_mode = migrate.add_mutually_exclusive_group(required=True)
    migration_mode.add_argument("--dry-run", action="store_true")
    migration_mode.add_argument("--apply", action="store_true")

    workspace = commands.add_parser("workspace")
    workspace_commands = workspace.add_subparsers(dest="workspace_command", required=True)
    add = workspace_commands.add_parser("add")
    add.add_argument("workspace")
    add.add_argument("repository")
    add.add_argument("root", type=Path)
    add.add_argument("--authority", action="store_true")
    add.add_argument("--display-name")
    add.add_argument(
        "--live-link", action="append", default=[], type=_live_link, metavar="PATH=ABSOLUTE_TARGET",
        help="allow one exact repository symlink for read-only live source inspection",
    )
    remove = workspace_commands.add_parser("remove")
    remove.add_argument("workspace")
    workspace_commands.add_parser("list")

    doctor = commands.add_parser("doctor")
    doctor.add_argument("--json", action="store_true", dest="as_json")
    doctor.add_argument("--tunnel", action="store_true")

    serve = commands.add_parser("serve")
    serve.add_argument("profile", nargs="?", choices=("observer", "coder", "codex", "mutator", "investigator", "skill_assembler"), default="observer")
    serve.add_argument("--host")
    serve.add_argument("--port", type=int)

    commands.add_parser("codex")
    commands.add_parser("mutator")

    assistance = commands.add_parser("assistance", help="use demand-only local assistance controls")
    assistance_commands = assistance.add_subparsers(dest="assistance_command", required=True)
    assistance_commands.add_parser("status")
    goal = assistance_commands.add_parser("goal")
    goal.add_argument("project")
    goal.add_argument("text")
    focus = assistance_commands.add_parser("focus")
    focus.add_argument("project")
    focus.add_argument("text")
    focus.add_argument("--repository")
    focus.add_argument("--path", action="append", default=[])
    focus.add_argument("--automatic", action="store_true",
                       help="explicitly permit bounded automatic preparation")
    focus.add_argument("--for", dest="duration")
    quiet = assistance_commands.add_parser("quiet")
    quiet_window = quiet.add_mutually_exclusive_group()
    quiet_window.add_argument("--for", dest="duration")
    quiet_window.add_argument("--until")
    quiet_window.required = True
    release = assistance_commands.add_parser("release")
    release.add_argument("--for", dest="duration")
    release.add_argument("--reason", default="operator-requested")
    resume = assistance_commands.add_parser("resume")
    resume_group = resume.add_mutually_exclusive_group(required=True)
    resume_group.add_argument("--quiet", action="store_true")
    resume_group.add_argument("--release", action="store_true")
    resume_group.add_argument("--all", action="store_true")
    dismiss = assistance_commands.add_parser("dismiss")
    dismiss.add_argument("project")
    dismiss.add_argument("--repository")
    dismiss.add_argument("focus_id")
    dismiss.add_argument("fingerprint")
    dismiss.add_argument("--reason", default="operator-dismissed")
    accept = assistance_commands.add_parser("accept")
    accept.add_argument("project")
    accept.add_argument("note_id")
    handoff = assistance_commands.add_parser("handoff")
    handoff.add_argument("project")
    handoff.add_argument("--focus-id")
    handoff.add_argument("--repository")
    ask = assistance_commands.add_parser("ask")
    ask.add_argument("question")
    ask.add_argument("--project", required=True)
    run = assistance_commands.add_parser("run", help="explicitly run one local question")
    run.add_argument("question")
    run.add_argument("--project", required=True)
    chat = assistance_commands.add_parser("chat")
    chat.add_argument("--project")

    plan = commands.add_parser("plan")
    plan_commands = plan.add_subparsers(dest="plan_command", required=True)
    compile_plan = plan_commands.add_parser("compile")
    compile_plan.add_argument("--package", type=Path, required=True)
    compile_plan.add_argument("--repository-label", required=True)
    compile_plan.add_argument("--output", type=Path, required=True)
    validate_plan = plan_commands.add_parser("validate")
    validate_plan.add_argument("--project", required=True)
    validate_plan.add_argument("--file", type=Path, required=True)
    apply_plan = plan_commands.add_parser("apply")
    apply_plan.add_argument("--project", required=True)
    apply_plan.add_argument("--file", type=Path, required=True)

    migrate_repo = commands.add_parser("migrate-repository")
    migrate_repo.add_argument("--repo", type=Path, required=True)
    mode = migrate_repo.add_mutually_exclusive_group(required=True)
    mode.add_argument("--dry-run", action="store_true")
    mode.add_argument("--apply", action="store_true")
    mode.add_argument("--remove", action="store_true")

    admin = commands.add_parser("admin")
    admin_commands = admin.add_subparsers(dest="admin_command", required=True)
    ingest_skill = admin_commands.add_parser("ingest-skill-archive")
    ingest_skill.add_argument("--skill", required=True)
    ingest_skill.add_argument("--resource", required=True)
    ingest_skill.add_argument("--destination", required=True)
    ingest_skill.add_argument("--apply", action="store_true")
    recover = admin_commands.add_parser("recover")
    recover.add_argument("--repo", required=True)
    recover.add_argument("--task")
    recover.add_argument("--reason", required=True)
    recover.add_argument("--inspect-only", action="store_true")
    delegated_recovery = admin_commands.add_parser("recover-authorized")
    delegated_recovery.add_argument("--repo", required=True)
    delegated_recovery.add_argument("--authorization", required=True)
    delegated_recovery.add_argument("--reason", required=True)
    prepare_maintenance = admin_commands.add_parser(
        "prepare-maintenance", help="issue one bounded maintenance assignment and operator launch packet"
    )
    prepare_maintenance.add_argument("--repo", required=True)
    prepare_maintenance.add_argument("--task", required=True)
    prepare_maintenance.add_argument("--run")
    prepare_maintenance.add_argument("--recipient", required=True)
    prepare_maintenance.add_argument("--expires", type=int, default=300)
    prepare_supersession = admin_commands.add_parser("prepare-supersession")
    prepare_supersession.add_argument("--repo", required=True)
    prepare_supersession.add_argument("--intent", required=True)
    prepare_supersession.add_argument("--recipient", required=True)
    prepare_supersession.add_argument("--expires", type=int, default=1800)
    retire_batch = admin_commands.add_parser("retire-run-batch")
    retire_batch.add_argument("--repo", required=True)
    retire_batch.add_argument("--request", required=True)
    retire_batch.add_argument("--apply", action="store_true")
    retire_batch.add_argument("--confirm")
    prepare_retire = admin_commands.add_parser("prepare-retire-run-batch")
    prepare_retire.add_argument("--repo", required=True)
    prepare_retire.add_argument("--intent", required=True)
    prepare_retire.add_argument("--output")
    prepare = admin_commands.add_parser("prepare-run-workspaces")
    prepare.add_argument("--repo", required=True)
    prepare.add_argument("--plan", required=True)
    prepare.add_argument("--run", required=True)
    prepare.add_argument("--lane")
    prepare.add_argument("--apply", action="store_true")
    prepare.add_argument("--confirm")
    reconcile = admin_commands.add_parser("reconcile-workspace-base")
    reconcile.add_argument("--repo", required=True)
    reconcile.add_argument("--run", required=True)
    reconcile.add_argument("--lane", required=True)
    reconcile.add_argument("--base", required=True)
    reconcile.add_argument("--reason", required=True)
    reconcile.add_argument("--apply", action="store_true")
    reconcile.add_argument("--confirm")
    cleanup = admin_commands.add_parser("mark-run-workspaces-cleanup-eligible")
    cleanup.add_argument("--repo", required=True)
    cleanup.add_argument("--run", required=True)
    cleanup.add_argument("--apply", action="store_true")
    cleanup.add_argument("--confirm")
    advance = admin_commands.add_parser("advance-producer-wave")
    advance.add_argument("--repo", required=True)
    advance.add_argument("--plan", required=True)
    advance.add_argument("--run", required=True)
    advance.add_argument("--lane", required=True)
    advance.add_argument("--base", required=True)
    advance.add_argument("--integration-task", required=True)
    advance.add_argument("--reason", required=True)
    advance.add_argument("--apply", action="store_true")
    advance.add_argument("--confirm")
    publish = admin_commands.add_parser("publish-producer-wave")
    publish.add_argument("--repo", required=True)
    publish.add_argument("--plan", required=True)
    publish.add_argument("--run", required=True)
    publish.add_argument("--lane", required=True)
    publish.add_argument("--apply", action="store_true")
    publish.add_argument("--confirm")
    binding = admin_commands.add_parser("bind-integration-gates")
    binding.add_argument("--repo", required=True)
    binding.add_argument("--plan", required=True)
    binding.add_argument("--run", required=True)
    binding.add_argument("--integration-task", required=True)
    binding.add_argument("--gates", required=True)
    binding.add_argument("--apply", action="store_true")
    binding.add_argument("--confirm")
    integration_wave = admin_commands.add_parser("integration-wave")
    integration_wave.add_argument("--repo", required=True)
    integration_wave.add_argument("--plan", required=True)
    integration_wave.add_argument("--run", required=True)
    integration_wave.add_argument("--integration-task", required=True)
    integration_wave.add_argument("--action", required=True, choices=("declare", "apply", "gate-finalize", "recover-finalization"))
    integration_wave.add_argument("--wave")
    integration_wave.add_argument("--adopt-gate-failed", action="store_true")
    integration_wave.add_argument("--legacy-provenance-reason")
    integration_wave.add_argument("--reason")
    integration_wave.add_argument("--apply", action="store_true")
    integration_wave.add_argument("--confirm")
    publish_interface = admin_commands.add_parser("publish-completed-interface")
    publish_interface.add_argument("--repo", required=True)
    publish_interface.add_argument("--plan", required=True)
    publish_interface.add_argument("--interface", required=True)
    publish_interface.add_argument("--source-worktree", required=True)
    publish_interface.add_argument("--apply", action="store_true")
    publish_interface.add_argument("--confirm")
    selective_replan = admin_commands.add_parser("selective-replan")
    selective_replan.add_argument("--project", required=True)
    selective_replan.add_argument("--file", type=Path, required=True)
    return parser


def _serve_profile(profile: str, *, host: str | None, port: int | None) -> int:
    """Start only a profile chosen by trusted process startup arguments."""

    if profile == "observer":
        from .app import serve

        return serve(host=host, port=port)
    if host is not None or port is not None:
        raise ValueError(f"{profile.capitalize()} stdio profile does not accept --host or --port")
    if profile in {"coder", "codex"}:
        from .app import serve_codex

        return serve_codex()
    if profile == "mutator":
        from .app import serve_mutator

        return serve_mutator()
    if profile in {"investigator", "skill_assembler"}:
        from .app import _serve_stdio
        from .profiles import MCPProfile
        return _serve_stdio(MCPProfile(profile))
    raise ValueError(f"unsupported MCP profile: {profile!r}")


def _load_native_plan(path: Path) -> dict[str, object]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ValueError(f"invalid native Todo plan: {exc}") from exc
    if not isinstance(value, dict):
        raise ValueError("native Todo plan root must be an object")
    return value


def _plan_command(args: argparse.Namespace) -> int:
    if args.plan_command == "compile":
        from .preledger import compile_preledger

        compiled = compile_preledger(args.package, target_repository=args.repository_label)
        args.output.write_text(compiled.canonical_plan_json(), encoding="utf-8")
        print(json.dumps({
            "status": "compiled",
            "output": str(args.output),
            "package_digest": compiled.package_digest,
            "plan_digest": compiled.plan_digest,
            "selected_task_count": compiled.selected_task_count,
            "excluded_task_count": compiled.excluded_task_count,
            "internal_dependency_count": compiled.internal_dependency_count,
            "external_dependencies": compiled.external_dependencies,
            "interfaces_imported": compiled.interfaces_imported,
            "warnings": compiled.warnings,
            "source_files": compiled.source_files,
        }, sort_keys=True, separators=(",", ":")))
        return 0

    from .mutation import apply_proposal, build_mutation_snapshot, validate_native_plan

    config = load_config()
    native_plan = _load_native_plan(args.file)
    if args.plan_command == "validate":
        result = validate_native_plan(config, args.project, native_plan)
    else:
        from .models import ProposalEnvelope
        from .proposals import observation_preconditions

        snapshot = build_mutation_snapshot(config, args.project)
        proposal = ProposalEnvelope.create(
            intent=f"Apply native Todo plan to {args.project}",
            proposed_change=native_plan,
            observation_preconditions=observation_preconditions(snapshot),
            created_at=snapshot.observed_at,
        )
        result = apply_proposal(config, args.project, proposal)
    print(json.dumps(result, sort_keys=True, separators=(",", ":")))
    return 0


def _assistance_composition(project: str):
    """Build the existing observer composition; callers start it only to ask."""
    from .app import Runtime
    from .as1_surface import compose_surface
    from .profiles import MCPProfile

    config = load_config()
    if project not in config.workspaces:
        raise PermissionError("project_not_registered")
    composition = compose_surface(Runtime(config), MCPProfile.OBSERVER)
    return config, composition


def _assistance_repository(config, project: str, repository: str | None = None) -> tuple[str, Path]:
    workspace = config.workspaces.get(project)
    if workspace is None:
        raise PermissionError("project_not_registered")
    alias = repository or workspace.authority_repository
    if alias is None:
        if len(workspace.repositories) != 1:
            raise ValueError("project_requires_authority_repository_or_explicit_repository")
        alias = next(iter(workspace.repositories))
    if alias not in workspace.repositories:
        raise ValueError("repository_not_registered_for_project")
    return alias, workspace.repositories[alias].root


def _assistance_ask(composition, question: str, project: str) -> dict[str, object]:
    """An explicit ask starts the ordinary two-worker broker for this process."""
    from .as1_surface import public_inquiry

    composition.start()
    scope = composition.scope(project)
    value = composition.jobs.inquire(question=question, access_scope=scope)
    if value.get("status") not in {"completed", "partial"}:
        return public_inquiry(value)
    job = value.get("job")
    if not isinstance(job, dict):
        return {"status": "unavailable", "reason": "answer_unavailable"}
    composition.jobs.reconcile()
    reference = job.get("result_packet")
    result = composition.store.lookup(reference, access_scope=scope) if reference else None
    if not result or result.status != "ok":
        return {"status": "unavailable", "reason": "answer_unavailable"}
    return public_inquiry({**result.packet.payload, "status": value["status"],
        "packet_id": result.packet.packet_id, "alias": result.packet.alias,
        "evidence_packets": job.get("evidence_packets", []),
        "unresolved_questions": job.get("unresolved_questions", []),
        "sources": [source.model_dump(exclude_none=True) for source in result.packet.sources]})


def _assistance_chat(args) -> int:
    """Line chat has no resident lease; ordinary lines are explicit questions."""
    from .assistance.operator import AssistanceOperator
    operator = AssistanceOperator()
    project = args.project
    composition = None
    print("Assistance chat. Use /status, /quiet DURATION, /release, /resume quiet|release|all, /accept NOTE_ID, /ask TEXT, /exit.")
    try:
        while True:
            try:
                line = input("you> ").strip()
            except EOFError:
                break
            if not line:
                continue
            if line in {"/exit", "/quit"}:
                break
            if line == "/status":
                print(json.dumps(operator.status(), sort_keys=True))
                continue
            if line.startswith("/quiet"):
                fields = line.split(maxsplit=1)
                from .assistance.operator import parse_duration
                if len(fields) != 2:
                    print("usage: /quiet DURATION")
                    continue
                until = operator.clock() + parse_duration(fields[1])
                print(json.dumps(operator.quiet(until=until), sort_keys=True))
                continue
            if line == "/release":
                if composition is None:
                    config = load_config()
                    if config.workspaces:
                        _, composition = _assistance_composition(
                            project or sorted(config.workspaces)[0])
                print(json.dumps(operator.request_release(
                    job_service=composition.jobs if composition is not None else None), sort_keys=True))
                continue
            if line.startswith("/resume "):
                selection = line.split(maxsplit=1)[1]
                print(json.dumps(operator.resume(quiet=selection in {"quiet", "all"},
                    release=selection in {"release", "all"}), sort_keys=True))
                continue
            if line.startswith("/accept "):
                fields = line.split(maxsplit=1)
                if not project:
                    print("select a registered project with --project")
                    continue
                config = load_config()
                result = operator.accept_suggestion(project=project, note_id=fields[1],
                                                    trusted_projects=set(config.workspaces))
                print(json.dumps(result, sort_keys=True))
                continue
            if line == "/ask" or line.startswith("/ask "):
                line = line[4:].strip()
                if not line:
                    print("question required")
                    continue
            if line.startswith("/"):
                print("unknown command")
                continue
            if not project:
                print("select a registered project with --project")
                continue
            if composition is None:
                _, composition = _assistance_composition(project)
            result = _assistance_ask(composition, line, project)
            print(json.dumps(result, sort_keys=True))
    finally:
        # No release claim is made here; dispatcher shutdown is only process
        # cleanup, and any unresolved owner state remains durable/pending.
        if composition is not None:
            composition.jobs.shutdown(timeout=1)
    return 0


def _assistance_command(args) -> int:
    from .assistance.operator import AssistanceOperator, parse_duration, parse_utc_timestamp

    operator = AssistanceOperator()
    command = args.assistance_command
    if command == "status":
        result = operator.status()
    elif command == "chat":
        return _assistance_chat(args)
    elif command in {"goal", "focus", "dismiss", "accept", "handoff"}:
        config = load_config()
        projects = set(config.workspaces)
        if command == "goal":
            result = operator.set_goal(project=args.project, text=args.text, trusted_projects=projects)
        elif command == "focus":
            automatic_seconds = None
            if args.automatic:
                if not args.duration or not args.path:
                    raise ValueError("automatic_focus_requires_paths_and_bounded_for_duration")
                automatic_seconds = parse_duration(args.duration)
                if automatic_seconds > 86400:
                    raise ValueError("automatic_focus_exceeds_24_hour_ceiling")
            elif args.duration:
                raise ValueError("--for_requires_explicit_--automatic")
            repository, trusted_root = _assistance_repository(config, args.project, args.repository)
            result = operator.set_focus(project=args.project, text=args.text,
                trusted_projects=projects, trusted_root=trusted_root, trusted_repository=repository,
                automatic_seconds=automatic_seconds, source_paths=args.path)
        elif command == "dismiss":
            repository, trusted_root = _assistance_repository(config, args.project, args.repository)
            result = operator.dismiss(project=args.project, focus_id=args.focus_id,
                fingerprint=args.fingerprint, trusted_projects=projects,
                trusted_root=trusted_root, trusted_repository=repository, reason=args.reason)
        elif command == "accept":
            result = operator.accept_suggestion(project=args.project, note_id=args.note_id,
                                                trusted_projects=projects)
        else:
            repository, trusted_root = _assistance_repository(config, args.project, args.repository)
            result = operator.handoff(project=args.project, focus_id=args.focus_id,
                trusted_projects=projects, trusted_root=trusted_root, trusted_repository=repository)
    elif command == "quiet":
        until = (operator.clock() + parse_duration(args.duration) if args.duration else
                 parse_utc_timestamp(args.until) if args.until else None)
        result = operator.quiet(until=until)
    elif command == "release":
        config = load_config()
        until = operator.clock() + parse_duration(args.duration) if args.duration else None
        composition = None
        try:
            if not config.workspaces:
                raise ValueError("no_registered_projects_for_observer_runtime")
            _, composition = _assistance_composition(sorted(config.workspaces)[0])
            result = operator.request_release(job_service=composition.jobs, until=until,
                                              reason=args.reason)
        except (OSError, RuntimeError, ValueError, PermissionError) as exc:
            result = operator.request_release(until=until, reason=args.reason)
            result["owner_setup"] = "unavailable"
            result["owner_setup_reason"] = type(exc).__name__
        finally:
            if composition is not None:
                composition.jobs.shutdown(timeout=1)
    elif command == "resume":
        result = operator.resume(quiet=args.quiet or args.all,
                                 release=args.release or args.all)
    elif command in {"ask", "run"}:
        _config, composition = _assistance_composition(args.project)
        try:
            result = _assistance_ask(composition, args.question, args.project)
        finally:
            composition.jobs.shutdown(timeout=1)
    else:
        raise ValueError("unsupported_assistance_command")
    print(json.dumps(result, sort_keys=True, separators=(",", ":")))
    return 0


def _doctor(*, tunnel: bool) -> tuple[bool, dict[str, object]]:
    terminal_sandbox = BubblewrapSandbox()
    probe = terminal_sandbox.probe_diagnostics()
    service_constraints = _terminal_service_constraints()
    service_compatible = service_constraints.get("compatible")
    from .profiles import profile_policy, MCPProfile, TEMPORARILY_INACTIVE
    checks: dict[str, object] = {
        "surface": {"profiles": {p.value: list(profile_policy(p).tool_names) for p in MCPProfile},
                    "temporarily_inactive": TEMPORARILY_INACTIVE, "automatic_overview": False},
        "config_path": str(config_path()),
        "internal_command_sandbox": {
            "backend": "bubblewrap",
            "installed": probe["installed"],
            "ready": bool(probe["ready"] and service_compatible is not False),
            "probe": probe,
            "service_constraints": service_constraints,
        },
        # This validates one import/runtime identity without opening an
        # authority. It does not expose ambient environment values or launch a
        # process.
        "workflow_runtime": runtime_diagnostics(),
        # Project Control can observe the existing local-worker supervisor but
        # owns no tool-capable launcher. This says nothing about an executor
        # configured by Todo itself.
        "executor_capabilities": {
            "local_worker_observation_adapter": {
                "status": "observation_only",
                "reason": "observer_only_local_worker_adapter",
                "supported_action": "consult_todo_executor_capabilities",
            },
            "project_control_tool_capable_launcher": {
                "status": "unavailable",
                "reason": "no_project_control_owned_tool_capable_launcher",
                "supported_action": "use_configured_todo_executor",
            },
        },
    }
    try:
        config = load_config()
        registry = WorkspaceRegistry(config)
        checks["config"] = "ok"
        checks["workspaces"] = sorted(config.workspaces)
        checks["ready"] = bool(config.workspaces)
        providers: dict[str, object] = {}
        builder = SnapshotBuilder(config)
        for workspace_id in config.workspaces:
            registry.workspace(workspace_id)
            provider = resolve_todo_provider(config, workspace_id)
            snapshot = builder.build(workspace_id)
            todo_warnings = snapshot.warnings_for("todo")
            providers[workspace_id] = {
                "skills_root": "ok" if resolve_skills_root(config, workspace_id) else "unavailable",
                "todo_provider": provider.local_diagnostics(),
                "todo": {
                    "status": "ok" if snapshot.todo_revision is not None else "unavailable",
                    "revision": snapshot.todo_revision,
                    "cause": todo_warnings[0] if todo_warnings else None,
                    "components": snapshot.todo_status.get("component_authority", {}),
                    "consistency": snapshot.todo_status.get("observation_consistency"),
                },
                "cuda": {
                    "status": snapshot.cuda.get("status", "unavailable"),
                    "cause": (snapshot.warnings_for("cuda") or [None])[0],
                },
                "local_worker": {
                    "status": snapshot.local_worker.get("status", "unavailable"),
                    "cause": (snapshot.warnings_for("worker") or [None])[0],
                },
            }
        checks["providers"] = providers
    except (FileNotFoundError, PermissionError, ValueError) as exc:
        checks.update(config="unavailable", ready=False, error=str(exc))
    if tunnel:
        checks["tunnel"] = "configuration template available; credentials intentionally not inspected"
    return bool(checks.get("config") == "ok"), checks


def main(argv: Sequence[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    try:
        if args.command == "config":
            if args.config_command == "init":
                print(init_config())
            else:
                result = apply_config_migration() if args.apply else migrate_config_dry_run()
                print(json.dumps(result, sort_keys=True))
            return 0
        if args.command == "workspace":
            config = load_config()
            registry = WorkspaceRegistry(config)
            if args.workspace_command == "add":
                registry.add_workspace(
                    args.workspace,
                    args.repository,
                    args.root,
                    authority=args.authority,
                    display_name=args.display_name,
                    live_links=dict(args.live_link) if args.live_link else None,
                )
                save_config(config)
                print(args.workspace)
            elif args.workspace_command == "remove":
                registry.remove_workspace(args.workspace)
                save_config(config)
                print(args.workspace)
            else:
                print(json.dumps(config_summary(config), sort_keys=True))
            return 0
        if args.command == "doctor":
            ok, result = _doctor(tunnel=args.tunnel)
            print(json.dumps(result, sort_keys=True) if args.as_json else result)
            return 0 if ok else 1
        if args.command == "serve":
            return _serve_profile(args.profile, host=args.host, port=args.port)
        if args.command == "codex":
            return _serve_profile("codex", host=None, port=None)
        if args.command == "mutator":
            return _serve_profile("mutator", host=None, port=None)
        if args.command == "assistance":
            return _assistance_command(args)
        if args.command == "plan":
            return _plan_command(args)
        if args.command == "migrate-repository":
            from .migration import migrate

            result = migrate(args.repo, apply=args.apply or args.remove, remove=args.remove)
            print(json.dumps(result, sort_keys=True))
            return 0
        if args.command == "admin":
            if args.admin_command == "ingest-skill-archive":
                from .config import configured_observer_skills_root
                from .skills import SkillRegistry
                from .skill_ingestion import ingest_skill_archive

                registry = SkillRegistry(configured_observer_skills_root(load_config()))
                result = ingest_skill_archive(
                    registry, args.skill, args.resource, args.destination, apply=args.apply,
                )
                print(json.dumps(result, sort_keys=True, separators=(",", ":")))
                return 0
            from .admin import (
                advance_producer_wave,
                inspect_recovery,
                mark_run_workspaces_cleanup_eligible,
                manage_integration_wave,
                bind_integration_gates,
                prepare_run_workspaces,
                publish_producer_wave,
                publish_completed_interface,
                reconcile_workspace_base,
                recover,
                recover_authorized,
                prepare_retire_run_batch,
                retire_run_batch,
                prepare_maintenance_assignment,
                prepare_supersession_assignment,
            )

            if args.admin_command == "selective-replan":
                from .mutation import apply_selective_replan

                request = _load_native_plan(args.file)
                result = apply_selective_replan(load_config(), args.project, request)
                print(json.dumps(result, sort_keys=True, separators=(",", ":")))
            elif args.admin_command == "publish-completed-interface":
                result = publish_completed_interface(
                    args.repo, args.plan, args.interface, args.source_worktree,
                    apply=args.apply, confirmation=args.confirm,
                )
                print(json.dumps(result, sort_keys=True, separators=(",", ":")))
            elif args.admin_command == "prepare-run-workspaces":
                result = prepare_run_workspaces(
                    args.repo, args.plan, args.run, lane_id=args.lane,
                    apply=args.apply, confirmation=args.confirm,
                )
                print(json.dumps(result, sort_keys=True, separators=(",", ":")))
            elif args.admin_command == "recover" and args.inspect_only:
                print(json.dumps(inspect_recovery(args.repo, args.task), sort_keys=True, separators=(",", ":")))
            elif args.admin_command == "recover":
                recover(args.repo, reason=args.reason, task_id=args.task)
            elif args.admin_command == "recover-authorized":
                result = recover_authorized(args.repo, authorization_id=args.authorization, reason=args.reason)
                print(json.dumps(result, sort_keys=True, separators=(",", ":")))
            elif args.admin_command == "prepare-maintenance":
                from .maintenance_host import operator_launch_command

                assignment = prepare_maintenance_assignment(
                    args.repo, task_id=args.task, run_id=args.run, recipient_principal=args.recipient,
                    expires_seconds=args.expires,
                )
                print(json.dumps({
                    **assignment,
                    "operator_launch": operator_launch_command(args.recipient),
                }, sort_keys=True, separators=(",", ":")))
            elif args.admin_command == "prepare-supersession":
                from .maintenance_host import operator_launch_command
                assignment = prepare_supersession_assignment(args.repo, args.intent, recipient_principal=args.recipient, expires_seconds=args.expires)
                print(json.dumps({**assignment, "operator_launch": operator_launch_command(args.recipient)}, sort_keys=True, separators=(",", ":")))
            elif args.admin_command == "retire-run-batch":
                result = retire_run_batch(args.repo, args.request, apply=args.apply, confirmation=args.confirm)
                print(json.dumps(result, sort_keys=True, separators=(",", ":")))
            elif args.admin_command == "prepare-retire-run-batch":
                result = prepare_retire_run_batch(args.repo, args.intent, args.output)
                print(json.dumps(result, sort_keys=True, separators=(",", ":")))
            elif args.admin_command == "reconcile-workspace-base":
                result = reconcile_workspace_base(
                    args.repo, args.run, args.lane, args.base, reason=args.reason,
                    apply=args.apply, confirmation=args.confirm,
                )
                print(json.dumps(result, sort_keys=True, separators=(",", ":")))
            elif args.admin_command == "mark-run-workspaces-cleanup-eligible":
                result = mark_run_workspaces_cleanup_eligible(
                    args.repo, args.run, apply=args.apply, confirmation=args.confirm,
                )
                print(json.dumps(result, sort_keys=True, separators=(",", ":")))
            elif args.admin_command == "advance-producer-wave":
                result = advance_producer_wave(
                    args.repo, args.plan, args.run, args.lane, args.base, args.integration_task,
                    reason=args.reason, apply=args.apply, confirmation=args.confirm,
                )
                print(json.dumps(result, sort_keys=True, separators=(",", ":")))
            elif args.admin_command == "bind-integration-gates":
                result = bind_integration_gates(args.repo, args.plan, args.run, args.integration_task, args.gates,
                                               apply=args.apply, confirmation=args.confirm)
                print(json.dumps(result, sort_keys=True, separators=(",", ":")))
            elif args.admin_command == "integration-wave":
                result = manage_integration_wave(
                    args.repo, args.plan, args.run, args.integration_task,
                    action=args.action, wave_id=args.wave,
                    adopt_gate_failed=args.adopt_gate_failed, apply=args.apply,
                    legacy_provenance_reason=args.legacy_provenance_reason,
                    reason=args.reason,
                    confirmation=args.confirm,
                )
                print(json.dumps(result, sort_keys=True, separators=(",", ":")))
            else:
                result = publish_producer_wave(
                    args.repo, args.plan, args.run, args.lane,
                    apply=args.apply, confirmation=args.confirm,
                )
                print(json.dumps(result, sort_keys=True, separators=(",", ":")))
            return 0
    except (FileNotFoundError, PermissionError, RegistryError, MigrationError, MutationRejected, PreledgerError, ValueError) as exc:
        print(f"project-control: {exc}", file=sys.stderr)
        return 2
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
