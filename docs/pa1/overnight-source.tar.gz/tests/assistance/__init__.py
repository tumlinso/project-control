"""Project assistance evaluation tests."""
